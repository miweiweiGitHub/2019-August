# net/metadata

## 项目简介

用于储存各种元信息
