#### warden/resolver

##### 项目简介

warden 的 服务发现模块，用于从底层的注册中心中获取Server节点列表并返回给GRPC
