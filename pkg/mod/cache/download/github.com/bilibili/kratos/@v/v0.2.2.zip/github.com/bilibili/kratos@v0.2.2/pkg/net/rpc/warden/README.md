#### net/rpc/warden

##### 项目简介

来自 bilibili 主站技术部的 RPC 框架，融合主站技术部的核心科技，带来如飞一般的体验。

##### 编译环境

- **请只用 Golang v1.9.x 以上版本编译执行**

##### 依赖包

- [grpc](google.golang.org/grpc)
