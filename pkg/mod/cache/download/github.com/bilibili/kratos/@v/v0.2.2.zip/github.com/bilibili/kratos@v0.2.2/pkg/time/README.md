# time

## 项目简介

Kratos的时间模块，主要用于mysql时间戳转换、配置文件读取并转换、Context超时时间比较
