# errgroup

提供带recover和并行数的errgroup，err中包含详细堆栈信息
