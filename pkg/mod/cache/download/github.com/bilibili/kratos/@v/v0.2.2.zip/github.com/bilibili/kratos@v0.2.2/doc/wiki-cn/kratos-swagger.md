### kratos tool swagger
```shell
kratos tool swagger serve api/api.swagger.json
```
执行命令后，浏览器会自动打开swagger文档地址。  
同时也可以查看更多的 [go-swagger](https://github.com/go-swagger/go-swagger) 官方参数进行使用。


-------------

[文档目录树](summary.md)
