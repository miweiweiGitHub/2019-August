#!/bin/bash

kratos tool protoc api.proto
