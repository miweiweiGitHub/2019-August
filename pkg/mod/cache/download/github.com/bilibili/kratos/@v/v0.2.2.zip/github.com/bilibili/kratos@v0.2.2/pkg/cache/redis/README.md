# cache/redis

##### 项目简介
1. 提供redis接口

#### 使用方式
请参考doc.go
